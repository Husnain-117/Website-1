<script>
// JavaScript code to handle the burger menu
const navList = document.querySelector('.nav-list');
const burger = document.querySelector('.burger');

burger.addEventListener('click', function() {
    navList.classList.toggle('active');
});
</script>